require 'mkmf'

create_makefile("sdbm")
